<template>
	<view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		
		onLoad(option){
			this._id = option._id
			this.getCourseTaskList(option);
		},
		
		methods: {
			
		}
	}
</script>

<style>

</style>
